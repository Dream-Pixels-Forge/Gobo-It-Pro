bl_info = {
    "name": "Gobo_It Pro",
    "blender": (3, 0, 0),
    "category": "Lighting",
    "author": "Dimona Patrick",
    "version": (2, 0, 1),
    "description": "Professional Gobo lighting system with advanced features and presets",
    "location": "View3D > Sidebar > Gobo It Pro"
}

import bpy
import os
import json
import time
from pathlib import Path
from mathutils import Vector
from bpy.types import PropertyGroup, Panel, Operator, UIList, AddonPreferences
from bpy.props import (FloatProperty, FloatVectorProperty, PointerProperty, StringProperty, 
                      BoolProperty, EnumProperty, CollectionProperty,
                      IntProperty)

# Utility functions
def get_preferences():
    """Get addon preferences"""
    return bpy.context.preferences.addons[__name__].preferences

def get_presets_directory():
    """Get or create the presets directory"""
    addon_name = bl_info["name"].replace(" ", "_").lower()
    presets_dir = os.path.join(bpy.utils.user_resource('SCRIPTS'), 'presets', addon_name)
    os.makedirs(presets_dir, exist_ok=True)
    return presets_dir

def serialize_color(color):
    """Convert color to serializable format"""
    return [float(c) for c in color]

def deserialize_color(color_list):
    """Convert serializable format back to color"""
    return [float(c) for c in color_list]

class GoboPreset:
    """Class to handle gobo presets"""
    @staticmethod
    def save_preset(context, preset_name):
        light = context.object
        props = light.gobo_it_props
        
        # Create preset data
        preset_data = {
            "version": bl_info["version"],
            "timestamp": time.time(),
            "properties": {
                "spot_size": props.spot_size,
                "spot_blend": props.spot_blend,
                "gobo_scale": props.gobo_scale,
                "gobo_rotation": props.gobo_rotation,
                
            },
            "light_data": {
                "energy": light.data.energy,
                "color": serialize_color(light.data.color),
                
            }
        }
        
        # Save image reference if exists
        if props.gobo_image:
            preset_data["gobo_image"] = {
                "name": props.gobo_image.name,
                "filepath": props.gobo_image.filepath,
            }
        
        # Save preset file
        preset_path = os.path.join(get_presets_directory(), f"{preset_name}.json")
        with open(preset_path, 'w', encoding='utf-8') as f:
            json.dump(preset_data, f, indent=2)
        
        return True

    @staticmethod
    def load_preset(context, preset_name):
        preset_path = os.path.join(get_presets_directory(), f"{preset_name}.json")
        
        try:
            with open(preset_path, 'r', encoding='utf-8') as f:
                preset_data = json.load(f)
            
            light = context.object
            props = light.gobo_it_props
            
            # Load properties
            for prop_name, value in preset_data["properties"].items():
                if hasattr(props, prop_name):
                    setattr(props, prop_name, value)
            
            # Load light data
            light.data.energy = preset_data["light_data"]["energy"]
            light.data.color = deserialize_color(preset_data["light_data"]["color"])
            
            # Load image if exists
            if "gobo_image" in preset_data:
                image_data = preset_data["gobo_image"]
                image = bpy.data.images.get(image_data["name"])
                
                if not image and os.path.exists(image_data["filepath"]):
                    image = bpy.data.images.load(image_data["filepath"])
                
                if image:
                    props.gobo_image = image
            
            return True
            
        except Exception as e:
            print(f"Error loading preset: {str(e)}")
            return False

class GoboItPreferences(AddonPreferences):
    bl_idname = __name__

    default_folder: StringProperty(
        name="Default Gobo Folder",
        subtype='DIR_PATH',
        default=""
    )
    
    show_advanced: BoolProperty(
        name="Show Advanced Options",
        default=False
    )
    
    auto_preview: BoolProperty(
        name="Auto Preview",
        default=True,
        description="Automatically update preview when changing parameters"
    )
    
    preview_size: EnumProperty(
        name="Preview Size",
        items=[
            ('SMALL', "Small", "Small preview"),
            ('MEDIUM', "Medium", "Medium preview"),
            ('LARGE', "Large", "Large preview")
        ],
        default='MEDIUM'
    )

    # Advanced Settings
    shadow_softness: FloatProperty(
        name="Shadow Softness",
        description="Default shadow softness for new gobo lights",
        default=0.1,
        min=0.0,
        max=1.0
    )

    use_custom_color: BoolProperty(
        name="Use Custom Default Color",
        description="Use custom default color for new gobo lights",
        default=False
    )

    default_color: FloatVectorProperty(
        name="Default Color",
        description="Default color for new gobo lights",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 1.0)
    )

    default_energy: FloatProperty(
        name="Default Energy",
        description="Default energy value for new gobo lights",
        default=1000.0,
        min=0.0,
        soft_max=100000.0
    )

    default_spot_size: FloatProperty(
        name="Default Spot Size",
        description="Default spot size for new gobo lights",
        default=1.0,
        min=0.0,
        max=3.14159,
        subtype='ANGLE'
    )

    show_light_settings: BoolProperty(
        name="Show Light Settings",
        description="Show additional light settings in the panel",
        default=True
    )

    show_transform_settings: BoolProperty(
        name="Show Transform Settings",
        description="Show transform settings in the panel",
        default=True
    )

    def draw(self, context):
        layout = self.layout

        # Basic Settings
        box = layout.box()
        box.label(text="Basic Settings", icon='SETTINGS')
        box.prop(self, "default_folder")
        box.prop(self, "auto_preview")
        box.prop(self, "preview_size")

        # Advanced Settings Toggle
        box = layout.box()
        row = box.row()
        row.prop(self, "show_advanced", icon='TRIA_DOWN' if self.show_advanced else 'TRIA_RIGHT')

        # Advanced Settings
        if self.show_advanced:
            box = layout.box()
            box.label(text="Advanced Settings", icon='PREFERENCES')

            # Default Light Settings
            col = box.column()
            col.label(text="Default Light Settings:", icon='LIGHT')
            col.prop(self, "default_energy")
            col.prop(self, "default_spot_size")
            col.prop(self, "shadow_softness")
            
            # Color Settings
            col = box.column()
            col.prop(self, "use_custom_color")
            if self.use_custom_color:
                col.prop(self, "default_color")

            # UI Settings
            box.label(text="UI Settings:", icon='INTERFACE')
            col = box.column()
            col.prop(self, "show_light_settings")
            col.prop(self, "show_transform_settings")

            # Info Box
            box = layout.box()
            col = box.column()
            col.label(text="Info:", icon='INFO')
            col.label(text="Advanced settings affect new gobo lights only")
            col.label(text="Existing lights will keep their current settings")


class GoboPresetItem(PropertyGroup):
    """Property group for storing preset items"""
    name: StringProperty()

class GoboItProperties(PropertyGroup):
    """Properties for the Gobo It Pro addon"""
    
    gobo_image: PointerProperty(
        name="Gobo Image",
        type=bpy.types.Image,
        description="Image to use as gobo pattern",
        update=lambda self, context: update_gobo_image(self, context)
    )
    
    # Single category definition
    category: EnumProperty(
        name="Category",
        description="Filter gobos by category",
        items=[
            ('ALL', "All", "Show all gobos"),
            ('PATTERNS', "Patterns", "Regular patterns"),
            ('TEXTURES', "Textures", "Organic textures"),
            ('EFFECTS', "Effects", "Special effects"),
            ('CUSTOM', "Custom", "User custom gobos")
        ],
        default='ALL'
    )
    
    # Basic Properties
    gobo_scale_x: FloatProperty(
        name="Scale X",
        description="Horizontal scale of the gobo pattern",
        default=1.0,
        min=0.1,
        max=10.0,
        update=lambda self, context: update_gobo_parameters(self, context, 'scale')
    )
    
    gobo_scale_y: FloatProperty(
        name="Scale Y",
        description="Vertical scale of the gobo pattern",
        default=1.0,
        min=0.1,
        max=10.0,
        update=lambda self, context: update_gobo_parameters(self, context, 'scale')
    )
    
    gobo_rotation: FloatProperty(
        name="Rotation",
        description="Rotation of the gobo pattern",
        default=0.0,
        min=-6.2831855,
        max=6.2831855,
        subtype='ANGLE',
        unit='ROTATION',
        update=lambda self, context: update_gobo_parameters(self, context, 'rotation')
    )
    
    gobo_position_x: FloatProperty(
        name="X Position",
        description="Horizontal position of the gobo pattern",
        default=0.0,
        soft_min=-1.0,
        soft_max=1.0,
        update=lambda self, context: update_gobo_parameters(self, context, 'position')
    )

    gobo_position_y: FloatProperty(
        name="Y Position", 
        description="Vertical position of the gobo pattern",
        default=0.0,
        soft_min=-1.0,
        soft_max=1.0,
        update=lambda self, context: update_gobo_parameters(self, context, 'position')
    )

    spot_size: FloatProperty(
        name="Spot Size",
        description="Size of the spot light beam",
        default=1.0,
        min=0.0,
        max=3.14159,
        subtype='ANGLE',
        unit='ROTATION'
    )

    spot_blend: FloatProperty(
        name="Spot Blend",
        description="Softness of the spot light edge",
        default=0.15,
        min=0.0,
        max=1.0
    )

# Update functions
def update_gobo_parameters(self, context, param_type):
    """Update gobo parameters in the node tree"""
    try:
        if not (context.object and context.object.type == 'LIGHT' and context.object.data.use_nodes):
            return

        nodes = context.object.data.node_tree.nodes
        
        mapping_node = next((n for n in nodes if n.type == 'MAPPING'), None)
        image_node = next((n for n in nodes if n.type == 'TEX_IMAGE'), None)
        
        if not all([mapping_node, image_node]):
            return
        
        if param_type == 'scale' and mapping_node:
            mapping_node.inputs[3].default_value = (self.gobo_scale_x, self.gobo_scale_y, 1.0)
        elif param_type == 'rotation' and mapping_node:
            mapping_node.inputs[2].default_value = (0, 0, self.gobo_rotation)
        elif param_type == 'position' and mapping_node:
            mapping_node.inputs[1].default_value = (self.gobo_position_x, self.gobo_position_y, 0)

    except Exception as e:
        print(f"Error updating gobo parameters: {str(e)}")


def update_gobo_image(self, context):
    """Update gobo image in the node tree"""
    try:
        if context.object and context.object.type == 'LIGHT' and context.object.data.use_nodes:
            nodes = context.object.data.node_tree.nodes
            image_node = next((n for n in nodes if n.type == 'TEX_IMAGE'), None)
            if image_node:
                image_node.image = self.gobo_image
    except Exception as e:
        print(f"Error updating gobo image: {str(e)}")

class OBJECT_OT_add_gobo_nodes(Operator):
    """Setup gobo nodes for the selected spot light and create tracking target"""
    bl_idname = "object.add_gobo_nodes"
    bl_label = "Setup Gobo"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            prefs = get_preferences()
            light = context.object
            if not light or light.type != 'LIGHT' or light.data.type != 'SPOT':
                self.report({'ERROR'}, "Please select a Spot light")
                return {'CANCELLED'}

            # Create empty object as target
            target = bpy.data.objects.new("Gobo_Target", None)
            target.empty_display_type = 'SPHERE'
            target.empty_display_size = 0.2
            
            # Link empty to scene
            context.scene.collection.objects.link(target)
            
            # Position empty 3 units in front of the light
            target.location = light.location + light.matrix_world.to_quaternion() @ Vector((0, 0, -3))
            
            # Add Track To constraint to light
            track_const = light.constraints.new(type='TRACK_TO')
            track_const.target = target
            track_const.track_axis = 'TRACK_NEGATIVE_Z'
            track_const.up_axis = 'UP_Y'
            
            # Setup nodes
            light_data = light.data
            light_data.use_nodes = True

            # Set default light intensity to 30000W
            light_data.energy = 30000
            
            # Try to set light unit if available (Blender 3.0+)
            try:
                light_data.light_unit = 'WATTS'
            except:
                pass  # Ignore if the property is not available

            nodes = light_data.node_tree.nodes
            links = light_data.node_tree.links
            
            # Clear existing nodes
            nodes.clear()
            
            # Create nodes
            geo = nodes.new(type="ShaderNodeNewGeometry")
            geo.location = (-600, 0)
            
            vector_transform = nodes.new(type="ShaderNodeVectorTransform")
            vector_transform.vector_type = 'NORMAL'
            vector_transform.convert_from = 'WORLD'
            vector_transform.convert_to = 'OBJECT'
            vector_transform.location = (-400, 0)
            
            mapping = nodes.new(type="ShaderNodeMapping")
            mapping.location = (-200, 0)
            
            image_texture = nodes.new(type="ShaderNodeTexImage")
            image_texture.location = (0, -100)
            
            emission = nodes.new(type="ShaderNodeEmission")
            emission.location = (400, 0)
            
            output = nodes.new(type="ShaderNodeOutputLight")
            output.location = (600, 0)
            
            # Create links
            links.new(geo.outputs[4], vector_transform.inputs[0])
            links.new(vector_transform.outputs[0], mapping.inputs[0])
            links.new(mapping.outputs[0], image_texture.inputs[0])
            links.new(image_texture.outputs[0], emission.inputs[1])
            links.new(emission.outputs[0], output.inputs[0])

            # Initialize properties
            props = light.gobo_it_props
            props.spot_size = light.data.spot_size
            props.spot_blend = light.data.spot_blend

            # Select the target empty
            light.select_set(False)
            target.select_set(True)
            context.view_layer.objects.active = target

            self.report({'INFO'}, "Gobo setup completed successfully with tracking target")
            return {'FINISHED'}

        except Exception as e:
            self.report({'ERROR'}, f"Setup failed: {str(e)}")
            return {'CANCELLED'}


class OBJECT_OT_reset_gobo_parameters(Operator):
    """Reset all gobo parameters to default values"""
    bl_idname = "object.reset_gobo_parameters"
    bl_label = "Reset Parameters"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            props = context.object.gobo_it_props
            props.gobo_scale_x = 1.0
            props.gobo_scale_y = 1.0
            props.gobo_rotation = 0.0
            props.gobo_position_x = 0.0
            props.gobo_position_y = 0.0
            
            self.report({'INFO'}, "Parameters reset to default values")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Reset failed: {str(e)}")
            return {'CANCELLED'}
    

class GOBO_UL_presets_list(UIList):
    """Custom UIList for gobo presets"""
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.label(text=item.name)

class GOBO_OT_add_preset(Operator):
    """Add a new preset"""
    bl_idname = "gobo.add_preset"
    bl_label = "Add Preset"
    bl_options = {'REGISTER', 'UNDO'}
    
    preset_name: StringProperty(
        name="Name",
        description="Name of the preset",
        default="New Preset"
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "preset_name")

    def execute(self, context):
        try:
            light = context.object
            if not light or light.type != 'LIGHT':
                self.report({'ERROR'}, "Please select a light")
                return {'CANCELLED'}

            scene = context.scene
            preset = scene.gobo_presets.add()
            preset.name = self.preset_name
            
            # Save preset data
            preset_data = {
                "light_data": {
                    "energy": light.data.energy,
                    "color": [c for c in light.data.color],
                    "spot_size": light.data.spot_size,
                    "spot_blend": light.data.spot_blend
                },
                "gobo_props": {
                    "scale_x": light.gobo_it_props.gobo_scale_x,
                    "scale_y": light.gobo_it_props.gobo_scale_y,
                    "rotation": light.gobo_it_props.gobo_rotation,
                    "position_x": light.gobo_it_props.gobo_position_x,
                    "position_y": light.gobo_it_props.gobo_position_y,
                }
            }

            # Save image reference if exists
            if light.gobo_it_props.gobo_image:
                preset_data["gobo_image"] = {
                    "name": light.gobo_it_props.gobo_image.name,
                    "filepath": light.gobo_it_props.gobo_image.filepath
                }

            # Save preset file
            preset_path = os.path.join(get_presets_directory(), f"{self.preset_name}.json")
            with open(preset_path, 'w', encoding='utf-8') as f:
                json.dump(preset_data, f, indent=2)

            scene.gobo_preset_index = len(scene.gobo_presets) - 1
            self.report({'INFO'}, f"Preset '{self.preset_name}' saved successfully")
            return {'FINISHED'}

        except Exception as e:
            self.report({'ERROR'}, f"Failed to save preset: {str(e)}")
            return {'CANCELLED'}

class GOBO_OT_remove_preset(Operator):
    """Remove the selected preset"""
    bl_idname = "gobo.remove_preset"
    bl_label = "Remove Preset"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            scene = context.scene
            if scene.gobo_preset_index >= 0 and len(scene.gobo_presets) > 0:
                preset = scene.gobo_presets[scene.gobo_preset_index]
                preset_path = os.path.join(get_presets_directory(), f"{preset.name}.json")
                
                # Remove file if exists
                if os.path.exists(preset_path):
                    os.remove(preset_path)
                
                # Remove from list
                scene.gobo_presets.remove(scene.gobo_preset_index)
                scene.gobo_preset_index = min(max(0, scene.gobo_preset_index - 1), len(scene.gobo_presets) - 1)
                
                self.report({'INFO'}, f"Preset '{preset.name}' removed")
                return {'FINISHED'}
            return {'CANCELLED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to remove preset: {str(e)}")
            return {'CANCELLED'}

class GOBO_OT_apply_preset(Operator):
    """Apply the selected preset"""
    bl_idname = "gobo.apply_preset"
    bl_label = "Apply Preset"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            scene = context.scene
            light = context.object

            if not light or light.type != 'LIGHT':
                self.report({'ERROR'}, "Please select a light")
                return {'CANCELLED'}

            if scene.gobo_preset_index >= 0 and len(scene.gobo_presets) > 0:
                preset = scene.gobo_presets[scene.gobo_preset_index]
                preset_path = os.path.join(get_presets_directory(), f"{preset.name}.json")

                if not os.path.exists(preset_path):
                    self.report({'ERROR'}, f"Preset file not found: {preset.name}")
                    return {'CANCELLED'}

                # Load and apply preset
                with open(preset_path, 'r', encoding='utf-8') as f:
                    preset_data = json.load(f)

                # Apply light data
                if "light_data" in preset_data:
                    light_data = preset_data["light_data"]
                    light.data.energy = light_data.get("energy", 1000)
                    light.data.color = light_data.get("color", [1, 1, 1])
                    light.data.spot_size = light_data.get("spot_size", 1.0)
                    light.data.spot_blend = light_data.get("spot_blend", 0.15)

                # Apply gobo properties
                if "gobo_props" in preset_data:
                    props = preset_data["gobo_props"]
                    light.gobo_it_props.gobo_scale_x = props.get("scale_x", 1.0)
                    light.gobo_it_props.gobo_scale_y = props.get("scale_y", 1.0)
                    light.gobo_it_props.gobo_rotation = props.get("rotation", 0.0)
                    light.gobo_it_props.gobo_position_x = props.get("position_x", 0.0)
                    light.gobo_it_props.gobo_position_y = props.get("position_y", 0.0)
                    

                # Load image if exists
                if "gobo_image" in preset_data:
                    image_data = preset_data["gobo_image"]
                    image = bpy.data.images.get(image_data["name"])
                    
                    if not image and os.path.exists(image_data["filepath"]):
                        image = bpy.data.images.load(image_data["filepath"])
                    
                    if image:
                        light.gobo_it_props.gobo_image = image

                self.report({'INFO'}, f"Applied preset '{preset.name}'")
                return {'FINISHED'}

            self.report({'ERROR'}, "No preset selected")
            return {'CANCELLED'}

        except Exception as e:
            self.report({'ERROR'}, f"Failed to apply preset: {str(e)}")
            return {'CANCELLED'}

class OBJECT_OT_load_gobo_folder(Operator):
    """Load all supported images from a folder as gobos"""
    bl_idname = "object.load_gobo_folder"
    bl_label = "Load Gobo Folder"
    
    directory: StringProperty(
        name="Directory",
        subtype='DIR_PATH'
    )
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    
    def execute(self, context):
        supported_formats = {'.png', '.jpg', '.jpeg', '.tiff', '.bmp', '.tga'}
        imported_count = 0
        
        try:
            for filename in os.listdir(self.directory):
                filepath = os.path.join(self.directory, filename)
                extension = os.path.splitext(filename)[1].lower()
                
                if extension in supported_formats:
                    try:
                        # Check if image is already loaded
                        img = bpy.data.images.get(filename)
                        if not img:
                            img = bpy.data.images.load(filepath)
                            imported_count += 1
                    except Exception as e:
                        self.report({'WARNING'}, f"Could not load {filename}: {str(e)}")
                        continue
            
            self.report({'INFO'}, f"Successfully imported {imported_count} images")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Error loading folder: {str(e)}")
            return {'CANCELLED'}

class VIEW3D_PT_gobo_it_main(Panel):
    """Main panel for Gobo It Pro"""
    bl_label = "Gobo It Pro"
    bl_idname = "VIEW3D_PT_gobo_it_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Gobo It"
    bl_context = "objectmode"

    def draw(self, context):
        layout = self.layout
        light = context.object
        scene = context.scene
        
        if not light or light.type != 'LIGHT' or light.data.type != 'SPOT':
            box = layout.box()
            box.label(text="Please select a Spot Light", icon='ERROR')
            return

        props = light.gobo_it_props
        prefs = get_preferences()

        # Setup Box
        box = layout.box()
        row = box.row()
        row.label(text="Gobo Setup", icon='LIGHT')
        row = box.row()
        row.operator("object.add_gobo_nodes", icon='NODETREE')

        # Image Selection Box
        box = layout.box()
        row = box.row()
        row.label(text="Gobo Image", icon='IMAGE')
        row = box.row()
        row.prop(props, "category", text="")
        row = box.row()
        row.template_ID_preview(props, "gobo_image", open="image.open", rows=3, cols=8)

        # Add bulk load button
        row = box.row()
        row.operator("object.load_gobo_folder", icon='FILE_FOLDER')

        if light.data.use_nodes:
            # Basic Parameters Box
            box = layout.box()
            row = box.row()
            row.label(text="Light Parameters", icon='LIGHT')
            
            col = box.column(align=True)
            col.prop(light.data, "color", text="")
            # Only show light_unit if it exists
            if hasattr(light.data, "light_unit"):
                col.prop(light.data, "light_unit", text="Light Unit")
            col.prop(light.data, "energy", text="Intensity")
            col.prop(light.data, "spot_size", text="Size")
            col.prop(light.data, "spot_blend", text="Blend")
            

            # Gobo Parameters Box
            box = layout.box()
            row = box.row(align=True)
            row.label(text="Gobo Parameters", icon='TEXTURE')
            row.operator("object.reset_gobo_parameters", text="", icon='LOOP_BACK')
            
            col = box.column(align=True)
            col.prop(props, "gobo_rotation", slider=True)
            col.prop(light.data, "shadow_soft_size", text="Softness")

            # Scale controls
            col = box.column(align=True)
            col.prop(props, "gobo_scale_x", text="Scale X", slider=True)
            col.prop(props, "gobo_scale_y", text="Scale Y", slider=True)

            # Position controls
            col = box.column(align=True)
            col.prop(props, "gobo_position_x", slider=True)
            col.prop(props, "gobo_position_y", slider=True)

            # Presets Box with template_list
            box = layout.box()
            row = box.row()
            row.label(text="Presets", icon='PRESET')
            
            # Preset list
            row = box.row()
            row.template_list("GOBO_UL_presets_list", "preset_list",
                            scene, "gobo_presets",
                            scene, "gobo_preset_index",
                            rows=3)
            
            # Preset buttons column
            col = row.column(align=True)
            col.operator("gobo.add_preset", text="", icon='ADD')
            col.operator("gobo.remove_preset", text="", icon='REMOVE')
            col.separator()
            col.operator("gobo.apply_preset", text="", icon='CHECKMARK')

            # Show selected preset name
            if len(scene.gobo_presets) > 0 and scene.gobo_preset_index >= 0:
                box.label(text=f"Selected: {scene.gobo_presets[scene.gobo_preset_index].name}")
            

# Registration
classes = [
    GoboItPreferences,
    GoboItProperties,
    GoboPresetItem,
    GOBO_UL_presets_list,
    OBJECT_OT_add_gobo_nodes,
    OBJECT_OT_reset_gobo_parameters,
    GOBO_OT_add_preset,
    GOBO_OT_remove_preset,
    GOBO_OT_apply_preset,
    OBJECT_OT_load_gobo_folder,
    VIEW3D_PT_gobo_it_main,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Object.gobo_it_props = PointerProperty(type=GoboItProperties)
    bpy.types.Scene.gobo_presets = CollectionProperty(type=GoboPresetItem)
    bpy.types.Scene.gobo_preset_index = IntProperty()

def unregister():
    del bpy.types.Scene.gobo_preset_index
    del bpy.types.Scene.gobo_presets
    del bpy.types.Object.gobo_it_props
    
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
