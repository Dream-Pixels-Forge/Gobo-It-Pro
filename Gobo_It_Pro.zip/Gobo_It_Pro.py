bl_info = {
    "name": "Gobo_It Pro",
    "blender": (3, 0, 0),
    "category": "Lighting",
    "author": "Dimona Patrick",
    "version": (2, 0, 0),
    "description": "Professional Gobo lighting system with advanced features and presets",
    "location": "View3D > Sidebar > Gobo It Pro",
    "warning": "",
    "doc_url": "",
    "tracker_url": ""
}

import bpy
import os
import json
import time
from pathlib import Path
from mathutils import Vector
from bpy.types import PropertyGroup, Panel, Operator
from bpy.props import (FloatProperty, PointerProperty, StringProperty, 
                      BoolProperty, EnumProperty, CollectionProperty)


# Utility functions
def get_preferences():
    """Get addon preferences"""
    return bpy.context.preferences.addons[__name__].preferences

def get_gobo_categories(self, context):
    """Define gobo categories"""
    items = [
        ('ALL', "All", "Show all gobos"),
        ('PATTERNS', "Patterns", "Regular patterns"),
        ('TEXTURES', "Textures", "Organic textures"),
        ('EFFECTS', "Effects", "Special effects"),
        ('CUSTOM', "Custom", "User custom gobos")
    ]
    return items

def get_presets_directory():
    """Get or create the presets directory"""
    addon_name = bl_info["name"].replace(" ", "_").lower()
    presets_dir = os.path.join(bpy.utils.user_resource('SCRIPTS'), 'presets', addon_name)
    os.makedirs(presets_dir, exist_ok=True)
    return presets_dir

def serialize_color(color):
    """Convert color to serializable format"""
    return [float(c) for c in color]

def deserialize_color(color_list):
    """Convert serializable format back to color"""
    return [float(c) for c in color_list]

class GoboPreset:
    """Class to handle gobo presets"""
    @staticmethod
    def save_preset(context, preset_name):
        light = context.object
        props = light.gobo_it_props
        
        # Create preset data
        preset_data = {
            "version": bl_info["version"],
            "timestamp": time.time(),
            "properties": {
                "spot_size": props.spot_size,
                "spot_blend": props.spot_blend,
                "gobo_scale": props.gobo_scale,
                "gobo_rotation": props.gobo_rotation,
                "gobo_opacity": props.gobo_opacity,
               
            },
            "light_data": {
                "energy": light.data.energy,
                "color": serialize_color(light.data.color),
            }
        }
        
        # Save image reference if exists
        if props.gobo_image:
            preset_data["gobo_image"] = {
                "name": props.gobo_image.name,
                "filepath": props.gobo_image.filepath,
            }
        
        # Save preset file
        preset_path = os.path.join(get_presets_directory(), f"{preset_name}.json")
        with open(preset_path, 'w', encoding='utf-8') as f:
            json.dump(preset_data, f, indent=2)
        
        return True

    @staticmethod
    def load_preset(context, preset_name):
        preset_path = os.path.join(get_presets_directory(), f"{preset_name}.json")
        
        try:
            with open(preset_path, 'r', encoding='utf-8') as f:
                preset_data = json.load(f)
            
            light = context.object
            props = light.gobo_it_props
            
            # Load properties
            for prop_name, value in preset_data["properties"].items():
                if hasattr(props, prop_name):
                    setattr(props, prop_name, value)
            
            # Load light data
            light.data.energy = preset_data["light_data"]["energy"]
            light.data.color = deserialize_color(preset_data["light_data"]["color"])
            
            # Load image if exists
            if "gobo_image" in preset_data:
                image_data = preset_data["gobo_image"]
                image = bpy.data.images.get(image_data["name"])
                
                if not image and os.path.exists(image_data["filepath"]):
                    image = bpy.data.images.load(image_data["filepath"])
                
                if image:
                    props.gobo_image = image
            
            return True
            
        except Exception as e:
            print(f"Error loading preset: {str(e)}")
            return False

    @staticmethod
    def get_presets():
        """Get list of available presets"""
        presets_dir = get_presets_directory()
        presets = []
        
        if os.path.exists(presets_dir):
            for file in os.listdir(presets_dir):
                if file.endswith('.json'):
                    preset_name = os.path.splitext(file)[0]
                    presets.append((preset_name, preset_name, ""))
        
        return presets if presets else [("none", "No Presets", "")]

class GoboItPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    default_folder: StringProperty(
        name="Default Gobo Folder",
        subtype='DIR_PATH',
        default=""
    )
    
    show_advanced: BoolProperty(
        name="Show Advanced Options",
        default=False
    )
    
    auto_preview: BoolProperty(
        name="Auto Preview",
        default=True,
        description="Automatically update preview when changing parameters"
    )
    
    preview_size: EnumProperty(
        name="Preview Size",
        items=[
            ('SMALL', "Small", "Small preview"),
            ('MEDIUM', "Medium", "Medium preview"),
            ('LARGE', "Large", "Large preview")
        ],
        default='MEDIUM'
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "default_folder")
        layout.prop(self, "show_advanced")
        layout.prop(self, "auto_preview")
        layout.prop(self, "preview_size")

class GoboItProperties(PropertyGroup):
    """Properties for the Gobo It Pro addon"""
    
    gobo_image: PointerProperty(
        name="Gobo Image",
        type=bpy.types.Image,
        description="Image to use as gobo pattern",
        update=lambda self, context: update_gobo_image(self, context)
    )
    
    # Single category definition
    category: EnumProperty(
        name="Category",
        description="Filter gobos by category",
        items=[
            ('ALL', "All", "Show all gobos"),
            ('PATTERNS', "Patterns", "Regular patterns"),
            ('TEXTURES', "Textures", "Organic textures"),
            ('EFFECTS', "Effects", "Special effects"),
            ('CUSTOM', "Custom", "User custom gobos")
        ],
        default='ALL'
    )
    
    # Basic Properties
    gobo_scale: FloatProperty(
        name="Scale",
        description="Scale of the gobo pattern",
        default=1.0,
        min=0.1,
        max=10.0,
        update=lambda self, context: update_gobo_parameters(self, context, 'scale')
    )
    
    gobo_rotation: FloatProperty(
        name="Rotation",
        description="Rotation of the gobo pattern",
        default=0.0,
        min=-6.2831855,
        max=6.2831855,
        subtype='ANGLE',
        unit='ROTATION',
        update=lambda self, context: update_gobo_parameters(self, context, 'rotation')
    )
    
    gobo_position_x: FloatProperty(
        name="X Position",
        description="Horizontal position of the gobo pattern",
        default=0.0,
        soft_min=-1.0,
        soft_max=1.0,
        update=lambda self, context: update_gobo_parameters(self, context, 'position')
    )

    gobo_position_y: FloatProperty(
        name="Y Position", 
        description="Vertical position of the gobo pattern",
        default=0.0,
        soft_min=-1.0,
        soft_max=1.0,
        update=lambda self, context: update_gobo_parameters(self, context, 'position')
    )

    gobo_opacity: FloatProperty(
        name="Opacity",
        description="Opacity of the gobo pattern",
        default=1.0,
        min=0.0,
        max=1.0,
        update=lambda self, context: update_gobo_parameters(self, context, 'opacity')
    )

    spot_size: FloatProperty(
        name="Spot Size",
        description="Size of the spot light beam",
        default=1.0,
        min=0.0,
        max=3.14159,
        subtype='ANGLE',
        unit='ROTATION'
    )

    spot_blend: FloatProperty(
        name="Spot Blend",
        description="Softness of the spot light edge",
        default=0.15,
        min=0.0,
        max=1.0
    )


# Update functions
def update_gobo_parameters(self, context, param_type):
    """Update gobo parameters in the node tree"""
    try:
        if not (context.object and context.object.type == 'LIGHT' and context.object.data.use_nodes):
            return

        nodes = context.object.data.node_tree.nodes
        
        mapping_node = next((n for n in nodes if n.type == 'MAPPING'), None)
        image_node = next((n for n in nodes if n.type == 'TEX_IMAGE'), None)
        mix_node = next((n for n in nodes if n.type == 'MIX_RGB'), None)
        
        if not all([mapping_node, image_node]):
            return
        
        if param_type == 'scale' and mapping_node:
            mapping_node.inputs[3].default_value = (self.gobo_scale, self.gobo_scale, self.gobo_scale)
        elif param_type == 'rotation' and mapping_node:
            mapping_node.inputs[2].default_value = (0, 0, self.gobo_rotation)
        elif param_type == 'position' and mapping_node:
            mapping_node.inputs[1].default_value = (self.gobo_position_x, self.gobo_position_y, 0)
        elif param_type == 'opacity' and mix_node:
            mix_node.inputs[0].default_value = self.gobo_opacity

    except Exception as e:
        print(f"Error updating gobo parameters: {str(e)}")

def update_gobo_image(self, context):
    """Update gobo image in the node tree"""
    try:
        if context.object and context.object.type == 'LIGHT' and context.object.data.use_nodes:
            nodes = context.object.data.node_tree.nodes
            image_node = next((n for n in nodes if n.type == 'TEX_IMAGE'), None)
            if image_node:
                image_node.image = self.gobo_image
    except Exception as e:
        print(f"Error updating gobo image: {str(e)}")

class OBJECT_OT_add_gobo_nodes(Operator):
    """Setup gobo nodes for the selected spot light and create tracking target"""
    bl_idname = "object.add_gobo_nodes"
    bl_label = "Setup Gobo"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            light = context.object
            if not light or light.type != 'LIGHT' or light.data.type != 'SPOT':
                self.report({'ERROR'}, "Please select a Spot light")
                return {'CANCELLED'}

            # Create empty object as target
            target = bpy.data.objects.new("Gobo_Target", None)
            target.empty_display_type = 'SPHERE'
            target.empty_display_size = 0.2
            
            # Link empty to scene
            context.scene.collection.objects.link(target)
            
            # Position empty 3 units in front of the light
            target.location = light.location + light.matrix_world.to_quaternion() @ Vector((0, 0, -3))
            
            # Add Track To constraint to light
            track_const = light.constraints.new(type='TRACK_TO')
            track_const.target = target
            track_const.track_axis = 'TRACK_NEGATIVE_Z'
            track_const.up_axis = 'UP_Y'
            
            # Setup nodes
            light_data = light.data
            light_data.use_nodes = True

            # Set default light intensity to 3000W
            light_data.energy = 3000
            light_data.light_unit = 'WATTS'

            nodes = light_data.node_tree.nodes
            links = light_data.node_tree.links
            
            # Clear existing nodes
            nodes.clear()
            
            # Create nodes
            geo = nodes.new(type="ShaderNodeNewGeometry")
            geo.location = (-600, 0)
            
            vector_transform = nodes.new(type="ShaderNodeVectorTransform")
            vector_transform.vector_type = 'NORMAL'
            vector_transform.convert_from = 'WORLD'
            vector_transform.convert_to = 'OBJECT'
            vector_transform.location = (-400, 0)
            
            mapping = nodes.new(type="ShaderNodeMapping")
            mapping.location = (-200, 0)
            
            image_texture = nodes.new(type="ShaderNodeTexImage")
            image_texture.location = (0, -100)
            
            mix_rgb = nodes.new(type="ShaderNodeMixRGB")
            mix_rgb.location = (200, -100)
            mix_rgb.inputs[0].default_value = 1.0  # Set opacity
            
            emission = nodes.new(type="ShaderNodeEmission")
            emission.location = (400, 0)
            
            output = nodes.new(type="ShaderNodeOutputLight")
            output.location = (600, 0)
            
            # Create links
            links.new(geo.outputs[4], vector_transform.inputs[0])
            links.new(vector_transform.outputs[0], mapping.inputs[0])
            links.new(mapping.outputs[0], image_texture.inputs[0])
            links.new(image_texture.outputs[0], mix_rgb.inputs[1])
            links.new(mix_rgb.outputs[0], emission.inputs[1])
            links.new(emission.outputs[0], output.inputs[0])

            # Initialize properties
            props = light.gobo_it_props
            props.spot_size = light.data.spot_size
            props.spot_blend = light.data.spot_blend

            # Select the target empty
            light.select_set(False)
            target.select_set(True)
            context.view_layer.objects.active = target

            self.report({'INFO'}, "Gobo setup completed successfully with tracking target")
            return {'FINISHED'}

        except Exception as e:
            self.report({'ERROR'}, f"Setup failed: {str(e)}")
            return {'CANCELLED'}

class OBJECT_OT_reset_gobo_parameters(Operator):
    """Reset all gobo parameters to default values"""
    bl_idname = "object.reset_gobo_parameters"
    bl_label = "Reset Parameters"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            props = context.object.gobo_it_props
            props.gobo_scale = 1.0
            props.gobo_rotation = 0.0
            props.gobo_position_x = 0.0
            props.gobo_position_y = 0.0
            props.gobo_opacity = 1.0
            self.report({'INFO'}, "Parameters reset to default values")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Reset failed: {str(e)}")
            return {'CANCELLED'}

class OBJECT_OT_save_gobo_preset(Operator):
    """Save current gobo settings as a preset"""
    bl_idname = "object.save_gobo_preset"
    bl_label = "Save Preset"
    bl_options = {'REGISTER', 'UNDO'}
    
    preset_name: StringProperty(
        name="Preset Name",
        default="New Preset",
        description="Name for the preset"
    )
    
    overwrite: BoolProperty(
        name="Overwrite Existing",
        default=False,
        description="Overwrite existing preset with the same name"
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "preset_name")
        
        # Show overwrite option if preset exists
        preset_path = os.path.join(get_presets_directory(), f"{self.preset_name}.json")
        if os.path.exists(preset_path):
            layout.prop(self, "overwrite")
            layout.label(text="Warning: Preset already exists!", icon='ERROR')

    def execute(self, context):
        preset_path = os.path.join(get_presets_directory(), f"{self.preset_name}.json")
        
        if os.path.exists(preset_path) and not self.overwrite:
            self.report({'ERROR'}, "Preset already exists. Enable overwrite to continue.")
            return {'CANCELLED'}
        
        if GoboPreset.save_preset(context, self.preset_name):
            self.report({'INFO'}, f"Preset '{self.preset_name}' saved successfully")
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, "Failed to save preset")
            return {'CANCELLED'}

class OBJECT_OT_load_gobo_preset(Operator):
    """Load a saved gobo preset"""
    bl_idname = "object.load_gobo_preset"
    bl_label = "Load Preset"
    bl_options = {'REGISTER', 'UNDO'}
    
    preset_name: EnumProperty(
        name="Preset",
        items=GoboPreset.get_presets,
        description="Select a preset to load"
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "preset_name")

    def execute(self, context):
        if self.preset_name == "none":
            self.report({'ERROR'}, "No presets available")
            return {'CANCELLED'}
            
        if GoboPreset.load_preset(context, self.preset_name):
            self.report({'INFO'}, f"Preset '{self.preset_name}' loaded successfully")
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, "Failed to load preset")
            return {'CANCELLED'}

class OBJECT_OT_load_gobo_folder(Operator):
    """Load all supported images from a folder as gobos"""
    bl_idname = "object.load_gobo_folder"
    bl_label = "Load Gobo Folder"
    
    directory: StringProperty(
        name="Directory",
        subtype='DIR_PATH'
    )
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    
    def execute(self, context):
        supported_formats = {'.png', '.jpg', '.jpeg', '.tiff', '.bmp', '.tga'}
        imported_count = 0
        
        try:
            for filename in os.listdir(self.directory):
                filepath = os.path.join(self.directory, filename)
                extension = os.path.splitext(filename)[1].lower()
                
                if extension in supported_formats:
                    try:
                        # Check if image is already loaded
                        img = bpy.data.images.get(filename)
                        if not img:
                            img = bpy.data.images.load(filepath)
                            imported_count += 1
                    except Exception as e:
                        self.report({'WARNING'}, f"Could not load {filename}: {str(e)}")
                        continue
            
            self.report({'INFO'}, f"Successfully imported {imported_count} images")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Error loading folder: {str(e)}")
            return {'CANCELLED'}

class VIEW3D_PT_gobo_it_main(Panel):
    """Main panel for Gobo It Pro"""
    bl_label = "Gobo It Pro"
    bl_idname = "VIEW3D_PT_gobo_it_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Gobo It"
    bl_context = "objectmode"

    def draw(self, context):
        layout = self.layout
        light = context.object
        
        if not light or light.type != 'LIGHT' or light.data.type != 'SPOT':
            box = layout.box()
            box.label(text="Please select a Spot Light", icon='ERROR')
            return

        props = light.gobo_it_props
        prefs = get_preferences()

        # Setup Box
        box = layout.box()
        row = box.row()
        row.label(text="Gobo Setup", icon='LIGHT')
        row = box.row()
        row.operator("object.add_gobo_nodes", icon='NODETREE')

        # Image Selection Box
        box = layout.box()
        row = box.row()
        row.label(text="Gobo Image", icon='IMAGE')
        row = box.row()
        row.prop(props, "category", text="")
        row = box.row()
        row.template_ID_preview(props, "gobo_image", open="image.open", rows=3, cols=8)

        # Add bulk load button
        row = box.row()
        row.operator("object.load_gobo_folder", icon='FILE_FOLDER')

        if light.data.use_nodes:
            # Basic Parameters Box
            box = layout.box()
            row = box.row()
            row.label(text="Light Parameters", icon='LIGHT')
            
            col = box.column(align=True)
            col.prop(light.data, "color", text="")
            col.prop(light.data, "light_unit", text="Light Unit")
            col.prop(light.data, "energy", text="Intensity")
            col.prop(light.data, "spot_size", text="Size")
            col.prop(light.data, "spot_blend", text="Blend")

            # Gobo Parameters Box
            box = layout.box()
            row = box.row(align=True)
            row.label(text="Gobo Parameters", icon='TEXTURE')
            row.operator("object.reset_gobo_parameters", text="", icon='LOOP_BACK')
            
            col = box.column(align=True)
            col.prop(props, "gobo_scale", slider=True)
            col.prop(props, "gobo_rotation", slider=True)
            col.prop(props, "gobo_opacity", slider=True)

            # Position controls
            col = box.column(align=True)
            col.prop(props, "gobo_position_x", slider=True)
            col.prop(props, "gobo_position_y", slider=True)

            # Presets Box
            box = layout.box()
            row = box.row()
            row.label(text="Presets", icon='PRESET')
            row = box.row(align=True)
            row.operator("object.save_gobo_preset", icon='FILE_TICK')
            row.operator("object.load_gobo_preset", icon='FILE_FOLDER')

# Registration
classes = [
    GoboItPreferences,
    GoboItProperties,
    OBJECT_OT_add_gobo_nodes,
    OBJECT_OT_save_gobo_preset,
    OBJECT_OT_load_gobo_preset,
    OBJECT_OT_load_gobo_folder,
    OBJECT_OT_reset_gobo_parameters,
    VIEW3D_PT_gobo_it_main,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Object.gobo_it_props = PointerProperty(type=GoboItProperties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Object.gobo_it_props

if __name__ == "__main__":
    register()
